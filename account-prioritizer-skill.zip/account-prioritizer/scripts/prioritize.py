#!/usr/bin/env python3
"""Rank CRM accounts for outbound outreach.

Usage:
    python prioritize.py --accounts ACCOUNTS.csv --events EVENTS.json [--out DIR]
                         [--top N] [--config CONFIG.json]

Writes prioritized_accounts.csv, review_queue.csv, and run_report.txt to --out.
All dates are derived from the data; nothing is anchored to the wall clock.
"""

import argparse
import json
import re
import sys
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------- config ----
# Every tunable lives here. Override any subset with --config CONFIG.json.
CONFIG = {
    # Fit: how much we would care if this account said yes.
    "tier_weights": {"Enterprise": 0.89, "Strategic": 0.85,
                     "Mid-Market": 0.58, "SMB": 0.22},
    "tier_fallback": 0.4,          # unlabelled tier -> mid-pack, not zero
    "fit_arr_weight": 0.6,         # remainder goes to tier

    # Intent: is this account showing interest right now.
    "event_weights": {"demo_request": 10, "webinar": 5, "content_download": 4,
                      "page_visit": 2, "email_open": 1},
    "event_weight_fallback": 1,    # unrecognised event type
    "half_life_days": 30,          # recency decay

    # Neglect: how long since a rep touched it.
    "neglect_cap_days": 180,
    "neglect_when_unknown": 0.5,

    # Final blend: priority = fit * (intent_weight*intent + rest*neglect)
    "intent_weight": 0.7,

    # Confidence penalties, subtracted from 1.0.
    "confidence_penalties": {"arr_missing": 0.30, "no_events": 0.30,
                             "tier_missing": 0.10, "date_missing": 0.10},
    "confidence_bins": [0.5, 0.8],  # <=0.5 Low, <=0.8 Medium, else High

    # Placeholder strings treated as missing in the tier column.
    "tier_placeholders": ["TBD", "N/A", "Unknown", ""],
}

FLAG_RULES = {
    "arr_invalid":  "ARR value was not a valid number - imputed median",
    "arr_missing":  "ARR missing - imputed median",
    "date_future":  "Last contact date was in the future - treated as unknown",
    "date_missing": "Last contact date missing - neglect set to neutral",
    "tier_missing": "Account tier missing or placeholder - default weight applied",
    "no_events":    "No engagement signals found",
    "was_merged":   "Merged from duplicate CRM records",
}

EVENT_LABEL = {"demo_request": "demo request", "webinar": "webinar attendance",
               "content_download": "content download", "page_visit": "page visit",
               "email_open": "email open"}

# ------------------------------------------------------ name normalisation ----
ABBREV = {
    r"\bfdn\b": "foundation",     r"\binst\b": "institute",
    r"\bintl\b": "international", r"\bdev\b": "development",
    r"\bcomm\b": "community",     r"\bamer\b": "america",
    r"\bww\b": "worldwide",       r"\bnatl\b": "national",
    r"\bassn\b": "association",   r"\bctr\b": "center",
    r"\bsvcs?\b": "services",     r"\bdept\b": "department",
}
SUFFIX = r"\b(incorporated|inc|llc|ltd|limited|corp|corporation|co|usa|us|the)\b"


def norm(s):
    """Collapse an org name to a comparable key: 'Goodwill Ind. Intl.' -> 'goodwillindustriesinternational'."""
    if pd.isna(s):
        return ""
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode()
    s = s.lower()
    s = re.sub(r"[.,&'/]", " ", s)          # punctuation to spaces so \b still fires
    for pat, rep in ABBREV.items():
        s = re.sub(pat, rep, s)
    s = re.sub(SUFFIX, " ", s)
    return re.sub(r"[^a-z0-9]", "", s)


# --------------------------------------------------------------- loading ----
REQUIRED_ACCOUNT_COLS = ["account_name"]
OPTIONAL_ACCOUNT_COLS = ["industry", "arr", "last_contact_date", "account_tier",
                         "website", "region", "owner"]


def load_accounts(path, report):
    accounts = pd.read_csv(path, dtype=str)
    missing = [c for c in REQUIRED_ACCOUNT_COLS if c not in accounts.columns]
    if missing:
        sys.exit(f"ERROR: accounts file is missing required column(s): {missing}")
    for col in OPTIONAL_ACCOUNT_COLS:
        if col not in accounts.columns:
            accounts[col] = pd.NA
            report.append(f"NOTE: column '{col}' absent from export; treated as empty.")
    report.append(f"Loaded {len(accounts)} account rows from {Path(path).name}.")
    return accounts


def load_events(path, report):
    if path is None:
        report.append("NOTE: no engagement file supplied; intent scores will all be 0.")
        return pd.DataFrame(columns=["account_name", "event_type", "event_date", "event_count"])
    with open(path) as f:
        raw = json.load(f)
    if isinstance(raw, dict):                       # tolerate {"events": [...]}
        raw = next(v for v in raw.values() if isinstance(v, list))
    events = pd.DataFrame(raw)
    for col in ["account_name", "event_type", "event_date", "event_count"]:
        if col not in events.columns:
            sys.exit(f"ERROR: engagement file is missing required field '{col}'.")
    report.append(f"Loaded {len(events)} engagement rows from {Path(path).name}.")
    return events


def derive_cutoff(events, contact_dates, report):
    """Anchor date for all recency maths, derived from the data.

    The engagement stream is machine-generated, so its latest timestamp is the
    most reliable statement of 'when this export was taken'. Contact dates after
    it are treated as data-entry errors. With no events, fall back to the 98th
    percentile of contact dates, which ignores stray far-future typos.
    """
    if len(events) and events["event_date"].notna().any():
        cutoff = events["event_date"].max()
        report.append(f"Data cutoff derived from latest engagement event: {cutoff.date()}.")
    else:
        cutoff = contact_dates.quantile(0.98)
        report.append(f"No usable event dates; cutoff derived from contact dates: {cutoff.date()}.")
    return cutoff


# ---------------------------------------------------------------- cleaning ----
def clean_accounts(accounts, cfg, cutoff, report):
    accounts["arr_num"] = pd.to_numeric(accounts["arr"], errors="coerce")
    accounts["arr_invalid"] = (
        (accounts["arr_num"].isna() & accounts["arr"].notna())   # present but unparseable
        | (accounts["arr_num"] < 0)                              # parses but implausible
    )
    accounts.loc[accounts["arr_num"] < 0, "arr_num"] = np.nan

    accounts["contact_date"] = pd.to_datetime(accounts["last_contact_date"], errors="coerce")
    accounts["date_future"] = accounts["contact_date"] > cutoff
    accounts.loc[accounts["date_future"], "contact_date"] = pd.NaT

    tier = accounts["account_tier"].fillna("").str.strip()
    tier = tier.mask(tier.isin(cfg["tier_placeholders"]), pd.NA)
    accounts["account_tier"] = tier
    accounts["tier_weight"] = tier.map(cfg["tier_weights"])

    unknown_tiers = sorted(set(tier.dropna()) - set(cfg["tier_weights"]))
    if unknown_tiers:
        report.append(f"NOTE: tier values with no configured weight: {unknown_tiers} "
                      f"(using fallback {cfg['tier_fallback']}).")

    accounts["domain"] = (
        accounts["website"].fillna("").astype(str).str.strip()
        .str.replace(r"^https?://", "", regex=True)
        .str.replace(r"^www\.", "", regex=True)
        .str.split("/").str[0].str.lower()
    )

    report.append(f"ARR unusable: {int(accounts['arr_num'].isna().sum())} "
                  f"(of which {int(accounts['arr_invalid'].sum())} present but invalid).")
    report.append(f"Contact date unusable: {int(accounts['contact_date'].isna().sum())} "
                  f"(of which {int(accounts['date_future'].sum())} future-dated).")
    report.append(f"Tier unusable: {int(accounts['tier_weight'].isna().sum())}.")
    return accounts


# ------------------------------------------------------------------- merge ----
def merge_duplicates(accounts, report):
    """Deduplicate on website domain. Names cannot do this: an initialism shares
    almost no characters with the full name it abbreviates."""
    valid = (accounts["domain"].str.match(r"^[a-z0-9-]+(\.[a-z0-9-]+)+$", na=False)
             & ~accounts["domain"].str.contains("@", na=False))
    groupable, passthrough = accounts[valid], accounts[~valid].copy()

    if (~valid).any():
        bad = accounts.loc[~valid, "account_name"].tolist()
        report.append(f"{len(bad)} account(s) have an unusable website field and bypass "
                      f"deduplication: {', '.join(bad[:5])}"
                      f"{' ...' if len(bad) > 5 else ''}.")

    merged = groupable.groupby("domain", as_index=False).agg(
        account_name=("account_name", lambda s: max(s, key=len)),
        arr_num=("arr_num", "max"),
        contact_date=("contact_date", "max"),
        tier_weight=("tier_weight", "max"),
        account_tier=("account_tier", lambda s: s.dropna().iloc[0] if s.notna().any() else None),
        industry=("industry", lambda s: s.dropna().iloc[0] if s.notna().any() else None),
        region=("region", "first"),
        owner=("owner", lambda s: " / ".join(sorted(s.dropna().astype(str).unique()))),
        arr_invalid=("arr_invalid", "any"),
        date_future=("date_future", "any"),
        source_names=("account_name", lambda s: " | ".join(sorted(s))),
        source_arr=("arr_num", lambda s: " | ".join(f"{v:,.0f}" for v in s.dropna())),
        row_count=("account_name", "size"),
    )

    passthrough["source_names"] = passthrough["account_name"]
    passthrough["source_arr"] = passthrough["arr_num"].apply(
        lambda v: "" if pd.isna(v) else f"{v:,.0f}")
    passthrough["row_count"] = 1

    out = pd.concat([merged, passthrough[merged.columns]], ignore_index=True)
    n_merged = int((out["row_count"] > 1).sum())
    report.append(f"Deduplicated {len(accounts)} rows -> {len(out)} accounts "
                  f"({n_merged} merged from multiple records).")
    return out


# ------------------------------------------------------------------- score ----
def score(am, events, cfg, cutoff, report):
    # --- join engagement by normalised name, via every source name ------------
    alias = {}
    for _, row in am.iterrows():
        for name in str(row["source_names"]).split(" | "):
            alias[norm(name)] = row["account_name"]

    if len(events):
        events = events.copy()
        events["event_date"] = pd.to_datetime(events["event_date"], errors="coerce")
        events["event_count"] = pd.to_numeric(events["event_count"], errors="coerce").fillna(1).clip(lower=0)
        events["matched_account"] = events["account_name"].map(norm).map(alias)

        unmatched = events["matched_account"].isna()
        if unmatched.any():
            names = sorted(events.loc[unmatched, "account_name"].unique())
            report.append(f"UNMATCHED: {int(unmatched.sum())} event row(s) across "
                          f"{len(names)} name(s) could not be matched to an account "
                          f"and are excluded: {', '.join(names[:10])}"
                          f"{' ...' if len(names) > 10 else ''}.")
        else:
            report.append("All engagement rows matched to an account.")

        events = events[~unmatched]

    if len(events):
        weights = events["event_type"].map(cfg["event_weights"])
        unknown = sorted(set(events.loc[weights.isna(), "event_type"].dropna()))
        if unknown:
            report.append(f"NOTE: event types with no configured weight: {unknown} "
                          f"(using fallback {cfg['event_weight_fallback']}).")
        weights = weights.fillna(cfg["event_weight_fallback"])

        days_ago = (cutoff - events["event_date"]).dt.days.clip(lower=0)
        decay = 0.5 ** (days_ago / cfg["half_life_days"])
        events["score"] = weights * np.log1p(events["event_count"]) * decay

        intent_raw = events.groupby("matched_account")["score"].sum()
        intent = intent_raw / intent_raw.max() if intent_raw.max() > 0 else intent_raw
        top_ev = (events.sort_values("score", ascending=False)
                        .groupby("matched_account")
                        .first()[["event_type", "event_date", "event_count"]])
    else:
        intent = pd.Series(dtype=float)
        top_ev = pd.DataFrame(columns=["event_type", "event_date", "event_count"])

    mapped = am["account_name"].map(intent)
    am["intent"] = mapped.fillna(0.0)
    am["no_events"] = mapped.isna()

    # --- flags captured before imputation, or the evidence is gone -----------
    am["arr_missing"] = am["arr_num"].isna()
    am["date_missing"] = am["contact_date"].isna()
    am["tier_missing"] = am["tier_weight"].isna()
    am["was_merged"] = am["row_count"] > 1

    # --- neutral imputation: unknown is mid-pack, never zero -----------------
    am["arr_num"] = am["arr_num"].fillna(am["arr_num"].median())
    am["tier_weight"] = am["tier_weight"].fillna(cfg["tier_fallback"])

    # --- the three components ------------------------------------------------
    fw = cfg["fit_arr_weight"]
    am["fit"] = fw * am["arr_num"].rank(pct=True) + (1 - fw) * am["tier_weight"]

    days_since = (cutoff - am["contact_date"]).dt.days
    am["neglect"] = ((days_since / cfg["neglect_cap_days"]).clip(0, 1)
                     .fillna(cfg["neglect_when_unknown"]))

    iw = cfg["intent_weight"]
    am["priority"] = am["fit"] * (iw * am["intent"] + (1 - iw) * am["neglect"])

    # --- confidence ----------------------------------------------------------
    penalty = sum(am[k] * w for k, w in cfg["confidence_penalties"].items())
    am["confidence_score"] = 1 - penalty
    lo, hi = cfg["confidence_bins"]
    am["confidence"] = pd.cut(am["confidence_score"], [-0.01, lo, hi, 1.01],
                              labels=["Low", "Medium", "High"])

    am["flags"] = am.apply(
        lambda r: "; ".join(FLAG_RULES[k] for k in FLAG_RULES if r.get(k, False)), axis=1)

    # --- reason strings ------------------------------------------------------
    arr_pct = am["arr_num"].rank(pct=True)

    def reason(r):
        bits = []
        p = arr_pct[r.name]
        if p >= 0.9:
            bits.append(f"top 10% by revenue ({r['arr_num']:,.0f})")
        elif p >= 0.7:
            bits.append(f"top 30% by revenue ({r['arr_num']:,.0f})")
        else:
            bits.append(f"{r['arr_num']:,.0f} ARR, {r['account_tier'] or 'untiered'}")

        if r["account_name"] in top_ev.index:
            t = top_ev.loc[r["account_name"]]
            d = int((cutoff - t["event_date"]).days)
            when = "in the last week" if d <= 7 else f"{d} days before data cutoff"
            label = EVENT_LABEL.get(t["event_type"], str(t["event_type"]))
            bits.append(f"strongest signal: {label} x{int(t['event_count'])} {when}")
        else:
            bits.append("no engagement on record")

        if r["date_missing"]:
            bits.append("last contact unknown")
        else:
            ds = int((cutoff - r["contact_date"]).days)
            if ds >= cfg["neglect_cap_days"]:
                bits.append(f"no rep contact in {ds} days")
            elif ds >= 90:
                bits.append(f"last contacted {ds} days ago")
        return "; ".join(bits)

    am["why"] = am.apply(reason, axis=1)

    ranked = am.sort_values("priority", ascending=False).reset_index(drop=True)
    ranked.insert(0, "rank", ranked.index + 1)

    mix = ranked["confidence"].value_counts().to_dict()
    report.append(f"Confidence mix: " + ", ".join(f"{k} {v}" for k, v in mix.items()))
    report.append(f"Low-confidence accounts in top 20: "
                  f"{int((ranked.head(20)['confidence'] == 'Low').sum())}.")
    return ranked


# ------------------------------------------------------------- sensitivity ----
def sensitivity(am, events, cfg, cutoff, baseline, runs=200, seed=0):
    """Perturb every weight +/-20% and measure how much the ranking moves."""
    import random
    random.seed(seed)
    base_top20 = set(baseline.head(20)["account_name"])
    base_rank = baseline.set_index("account_name")["priority"].rank()
    overlaps, corrs = [], []

    for _ in range(runs):
        c = json.loads(json.dumps(cfg))
        c["event_weights"] = {k: v * random.uniform(0.8, 1.2)
                              for k, v in cfg["event_weights"].items()}
        c["fit_arr_weight"] = min(cfg["fit_arr_weight"] * random.uniform(0.8, 1.2), 0.99)
        c["intent_weight"] = min(cfg["intent_weight"] * random.uniform(0.8, 1.2), 0.99)
        c["half_life_days"] = cfg["half_life_days"] * random.uniform(0.8, 1.2)
        r = score(am.copy(), events, c, cutoff, [])
        overlaps.append(len(set(r.head(20)["account_name"]) & base_top20) / 20)
        corrs.append(r.set_index("account_name")["priority"].rank()
                      .corr(base_rank, method="spearman"))

    return {"runs": runs,
            "top20_overlap_mean": float(np.mean(overlaps)),
            "top20_overlap_min": float(np.min(overlaps)),
            "spearman_mean": float(np.mean(corrs)),
            "spearman_min": float(np.min(corrs))}


# -------------------------------------------------------------------- main ----
OUTPUT_COLS = ["rank", "account_name", "priority", "confidence", "why", "flags",
               "fit", "intent", "neglect", "arr_num", "account_tier", "industry",
               "region", "owner", "source_names", "source_arr"]


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--accounts", required=True, help="Path to the account export (CSV).")
    ap.add_argument("--events", default=None, help="Path to the engagement export (JSON).")
    ap.add_argument("--out", default=".", help="Output directory.")
    ap.add_argument("--top", type=int, default=15, help="How many rows to print.")
    ap.add_argument("--config", default=None, help="JSON file overriding any config key.")
    ap.add_argument("--sensitivity", action="store_true",
                    help="Run the weight-perturbation check (slower).")
    args = ap.parse_args()

    cfg = dict(CONFIG)
    if args.config:
        cfg.update(json.load(open(args.config)))

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    report = []

    accounts = load_accounts(args.accounts, report)
    events = load_events(args.events, report)
    if len(events):
        events["event_date"] = pd.to_datetime(events["event_date"], errors="coerce")

    contact_dates = pd.to_datetime(accounts["last_contact_date"], errors="coerce")
    cutoff = derive_cutoff(events, contact_dates, report)

    accounts = clean_accounts(accounts, cfg, cutoff, report)
    am = merge_duplicates(accounts, report)
    ranked = score(am.copy(), events, cfg, cutoff, report)

    if args.sensitivity:
        s = sensitivity(am.copy(), events, cfg, cutoff, ranked)
        report.append(f"Sensitivity ({s['runs']} runs, all weights +/-20%): "
                      f"Spearman {s['spearman_mean']:.3f} (worst {s['spearman_min']:.3f}), "
                      f"top-20 overlap {s['top20_overlap_mean']:.0%} "
                      f"(worst {s['top20_overlap_min']:.0%}).")

    cols = [c for c in OUTPUT_COLS if c in ranked.columns]
    ranked[cols].to_csv(out_dir / "prioritized_accounts.csv", index=False)

    review = ranked[(ranked["confidence"] == "Low") | ranked["arr_invalid"]
                    | ranked["date_future"] | ranked["was_merged"]]
    review[["rank", "account_name", "confidence", "flags", "source_names",
            "source_arr"]].to_csv(out_dir / "review_queue.csv", index=False)
    report.append(f"Review queue: {len(review)} account(s) need a human look.")

    print("\n".join(report))
    print()
    for _, r in ranked.head(args.top).iterrows():
        print(f"{r['rank']:>3}. {r['account_name']}  [{r['priority']:.3f}]  "
              f"confidence: {r['confidence']}")
        print(f"     why:   {r['why']}")
        if r["flags"]:
            print(f"     flags: {r['flags']}")
        print(f"     owner: {r['owner']}  |  fit {r['fit']:.2f}  "
              f"intent {r['intent']:.2f}  neglect {r['neglect']:.2f}")
        print()

    (out_dir / "run_report.txt").write_text("\n".join(report) + "\n")
    print(f"Wrote {out_dir/'prioritized_accounts.csv'}, "
          f"{out_dir/'review_queue.csv'}, {out_dir/'run_report.txt'}")


if __name__ == "__main__":
    main()
