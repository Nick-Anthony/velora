---
name: account-prioritizer
description: Rank sales accounts for outbound calling from CRM exports. Use when someone uploads or points at an account export (CSV with names, revenue, tier, last-contact dates) and an engagement or activity file, and wants to know who to call first, which accounts are being neglected, or a prioritized outreach list. Also use for questions like "who should my SDRs call this week", "which accounts are we ignoring", or "score these accounts". Handles duplicate records, missing fields, and invalid values, and explains why each account ranks where it does.
---

# Account prioritizer

Turns two CRM exports into a ranked call list with a reason and a confidence
rating on every row.

## When to use this

Trigger on: a request to prioritize, rank, or score accounts for outreach; an
uploaded CRM account export plus an engagement/activity file; questions about
which accounts are being under-worked.

Do **not** use for: forecasting, pipeline reporting, territory design, or
scoring individual leads/contacts rather than accounts.

## Running it

Files uploaded to the chat land in the uploads directory. Pass their paths
directly — do not copy or rewrite them first.

```bash
python scripts/prioritize.py \
    --accounts <path to accounts CSV> \
    --events   <path to engagement JSON> \
    --out      <output directory> \
    --top 15
```

Add `--sensitivity` to also report how much the ranking depends on the weights
(200 perturbation runs, a few seconds). Add `--config my_weights.json` to
override any configuration key.

`--events` is optional. Without it every account scores zero on intent and the
ranking falls back to fit and neglect alone; the run report says so.

Three files are written to `--out`:

| file | contents |
|---|---|
| `prioritized_accounts.csv` | the ranked list — rank, priority, confidence, reason, flags, component scores |
| `review_queue.csv` | records needing a human: low confidence, invalid values, merged duplicates |
| `run_report.txt` | what was loaded, cleaned, merged, and flagged |

Show the printed top-N in chat and offer the CSVs. Lead with the top few
accounts and their reasons, not with the mechanics.

## Expected input

Accounts CSV needs `account_name`. It will use, if present: `arr`,
`account_tier`, `last_contact_date`, `website`, `industry`, `region`, `owner`.
Absent optional columns are reported and treated as empty rather than failing.

Engagement JSON is an array of objects with `account_name`, `event_type`,
`event_date`, `event_count`.

If the user's columns are named differently, rename them in a copy of the file
before running rather than editing the script.

## How the score works

`priority = fit × (0.7·intent + 0.3·neglect)`

- **Fit** — would we care if they said yes. ARR percentile blended with tier weight.
- **Intent** — are they showing interest now. Each event scored as
  `type_weight × log1p(count) × 0.5^(days_ago / half_life)`, summed and normalised.
- **Neglect** — days since a rep last made contact, capped.

Fit **multiplies** rather than adds, so a large account with no activity does not
surface as a call. Both conditions have to hold.

Explain it this way if asked, and mention that intent and neglect are separate:
an account that stopped engaging is a risk, an account nobody has called is an
opportunity, and averaging them together loses that difference.

## Dates come from the data

The anchor for all recency maths is the latest engagement event date, not
today's date. The engagement stream is machine-generated, so its last timestamp
is the most reliable statement of when the export was taken. Contact dates after
that anchor are treated as data-entry errors and flagged.

This means results are reproducible: re-running the same export next month gives
the same ranking. Never substitute the current date.

## Data quality behaviour

Missing values are imputed **neutral, never zero** — zero-filling would penalise
an account for CRM hygiene rather than for anything real. ARR gaps take the
median, tier gaps take a mid-pack default, an unknown contact date sets neglect
to 0.5.

Every imputation becomes a flag on the row and lowers the confidence rating.
Low-confidence accounts are still ranked and shown — never suppressed, because
suppressing them recreates the problem the tool exists to fix.

Duplicates are detected by **website domain, not name**. An initialism shares
almost no characters with the full name it abbreviates, so string similarity
cannot connect `AFSC` to `American Friends Service Committee`. Merged rows keep
both source names and both revenue figures for audit.

Engagement rows are joined by a normalised name key (case folded, accents
stripped, legal suffixes and common abbreviations resolved). Any row that fails
to match is excluded and named in the run report — mention these to the user,
since silently dropping engagement makes a live account look dead.

## Tuning

Weights live in the `CONFIG` dict at the top of the script and can be overridden
per-run with `--config`. Common asks:

- "weight demo requests higher" → `event_weights`
- "recency matters more" → lower `half_life_days`
- "care more about neglected accounts" → lower `intent_weight`
- "our tiers are named differently" → `tier_weights`

When a user changes a weight, offer to re-run with `--sensitivity` so they can
see whether the change actually moved the ranking.

## What to tell users about limits

The weights are informed priors, not fitted values — the exports contain no
conversion outcomes, so nothing can be trained or validated against. Ranking
accuracy cannot be measured from this data, and no accuracy figure should be
quoted. If asked how to know whether it works, the honest answer is a live
comparison: half the team works the ranked list, half works as usual, compared
on meetings booked per 100 calls. That also produces the first outcome labels.

Do not present the priority score as a probability or a prediction.
